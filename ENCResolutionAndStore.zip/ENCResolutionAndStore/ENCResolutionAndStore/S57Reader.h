// S57Reader.h : main header file for the S57READER application
//

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#ifndef __AFXWIN_H__
//	#error include 'stdafx.h' before including this file for PCH
//#endif

//#include "resource.h"       // main symbols
using namespace std;
#include<vector>
#include <list>

class EleChartWaypoint
{
public:
	float longitude, latitude, elevation;
	int waypoint_ID;

	class EleChartWaypoint() :longitude(0), latitude(0), waypoint_ID(0)
	{
	}

	class EleChartWaypoint(float _longitude, float _latitude, int _waypoint_ID)
	{
		this->longitude = _longitude;
		this->latitude = _latitude;
		this->waypoint_ID = _waypoint_ID;
	}
};

class GeoFeature
{
public:
	int Feature_ID;
	int Feature_layer;
	double Feature_valdco;
	string Feature_Type;
	list<EleChartWaypoint> EleChartWaypointlist;
};

class EncLayer
{
public:
	int layer_ID;
	string layer_Name;
	list<GeoFeature> GeoFeaturelist;
};

class EleChartInfo
{
public:
	string Chart_Name;
	list<EncLayer> Geolayerlist;
};
/////////////////////////////////////////////////////////////////////////////
// CS57ReaderApp:
// See S57Reader.cpp for the implementation of this class
//
//
//class CS57ReaderApp
//{
//public:
//void InputToTxtFile(string txtFilePath, string writeString);
//void InputDoubleToTxtFile(string txtFilePath, double writeString);
//string DoubleToString(double writeString);
//string AngleTransfer(double angle);
void SavetoXML(const char* pFilename, EleChartInfo Geolayer);
void OpenS57File(string lpFileName, list<int> ObjlList, double filter_lllat, double filter_urlat, double filter_lllon, double filter_urlon);
//};
